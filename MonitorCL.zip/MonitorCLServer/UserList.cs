﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MonitorCLServer
{
    public class UserList
    {
        int id = -1;
        string login = "";
        string name = "";
        int parentId = -1;
    }
}
